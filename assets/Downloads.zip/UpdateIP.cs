using System;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Collections.Generic;

class Program {
    static void Main(string[] args) {
        string configFile = "UpdateIP.ini";

        try {
            if (!File.Exists(configFile)) {
                Console.WriteLine("Error: Configuration file " + configFile + " not found.");
                return;
            }

            // Simple parser to get values from the INI
            var settings = ReadIni(configFile);
            
            string hostname = settings.ContainsKey("DynDnsHost") ? settings["DynDnsHost"] : "";
            string targetPath = settings.ContainsKey("TargetIniFile") ? settings["TargetIniFile"] : "";
            string targetKey = settings.ContainsKey("TargetKey") ? settings["TargetKey"] : "";

            if (string.IsNullOrEmpty(hostname) || string.IsNullOrEmpty(targetPath)) {
                Console.WriteLine("Error: Missing DynDnsHost or TargetIniFile in " + configFile);
                return;
            }

            Console.WriteLine("Resolving: " + hostname);
            IPAddress[] addresses = Dns.GetHostAddresses(hostname);
            
            if (addresses.Length > 0) {
                string ip = addresses[0].ToString();
                Console.WriteLine("Current IP: " + ip);

                if (File.Exists(targetPath)) {
                    string content = File.ReadAllText(targetPath);
                    string pattern = "^(" + Regex.Escape(targetKey) + "\\s*=\\s*).*";
                    string newContent = Regex.Replace(content, pattern, targetKey + "=" + ip, RegexOptions.Multiline);

                    File.WriteAllText(targetPath, newContent);
                    Console.WriteLine("Successfully updated " + targetPath);
                } else {
                    Console.WriteLine("Error: Target file not found: " + targetPath);
                }
            }
        } catch (Exception ex) {
            Console.WriteLine("Critical Error: " + ex.Message);
        }

        System.Threading.Thread.Sleep(2000);
    }

    // Helper to read simple KEY=VALUE pairs from INI
    static Dictionary<string, string> ReadIni(string path) {
        var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var line in File.ReadAllLines(path)) {
            var trimmed = line.Trim();
            if (trimmed.StartsWith("[") || string.IsNullOrEmpty(trimmed) || trimmed.StartsWith(";")) continue;
            
            int idx = trimmed.IndexOf('=');
            if (idx != -1) {
                string key = trimmed.Substring(0, idx).Trim();
                string val = trimmed.Substring(idx + 1).Trim();
                dict[key] = val;
            }
        }
        return dict;
    }
}