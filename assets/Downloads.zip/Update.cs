using System;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;

class Program {
    static void Main(string[] args) {
        // --- Configuration ---
        string hostname = "melia.ddnss.de";
        string iniPath = "RuneDev.ini";
        string key = "IP";
        // ---------------------

        try {
            Console.WriteLine("Resolving " + hostname + "...");
            IPAddress[] addresses = Dns.GetHostAddresses(hostname);
            
            if (addresses.Length > 0) {
                string ip = addresses[0].ToString();
                Console.WriteLine("Found IP: " + ip);

                if (File.Exists(iniPath)) {
                    string content = File.ReadAllText(iniPath);
                    
                    // Regex to find the key and replace its value
                    string pattern = "^(" + key + "\\s*=\\s*).*";
                    string newContent = Regex.Replace(content, pattern, "IP=" + ip, RegexOptions.Multiline);

                    File.WriteAllText(iniPath, newContent);
                    Console.WriteLine("Successfully updated " + iniPath);
                } else {
                    Console.WriteLine("Error: File not found: " + iniPath);
                }
            }
        } catch (Exception ex) {
            Console.WriteLine("Error: " + ex.Message);
        }

        // Keep window open for 3 seconds so you can see the result
        System.Threading.Thread.Sleep(3000);
    }
}